#!/bin/bash



sudo yum install telnet -y 